package com.swapily.swapilybackend.Repository;

import com.swapily.swapilybackend.Entity.Avis;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AvisRepository
        extends JpaRepository<Avis, Long> {

    // Tous les avis triés du plus récent au plus ancien
    List<Avis> findAllByOrderByIdDesc();

    // Avis d'un utilisateur
    List<Avis> findByUtilisateurIdOrderByIdDesc(
            Long utilisateurId
    );
}