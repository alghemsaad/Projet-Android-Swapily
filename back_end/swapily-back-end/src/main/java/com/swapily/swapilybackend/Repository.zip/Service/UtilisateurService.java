package com.swapily.swapilybackend.Service;
import lombok.RequiredArgsConstructor;
import com.swapily.swapilybackend.Entity.*;
import com.swapily.swapilybackend.Repository.*;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor

public class UtilisateurService {

    private final UtilisateurRepository utilisateurRepository;

    private final ProduitRepository produitRepository;

    private final DemmandechangeRepository demmandechangeRepository;

    private final ImageEchangeRepository imageEchangeRepository;

    private final EvaluationRepository evaluationRepository;

    // Signup
    public Utilisateur signUp(Utilisateur utilisateur) {

        if(utilisateurRepository.existsByEmail(
                utilisateur.getEmail()
        )) {

            throw new RuntimeException(
                    "Email already exists"
            );
        }

        return utilisateurRepository.save(utilisateur);
    }

    // Signin
    public Utilisateur signIn(Utilisateur utilisateur) {

        Utilisateur existingUser =
                utilisateurRepository
                        .findByEmail(utilisateur.getEmail())
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "Utilisateur introuvable"
                                )
                        );

        if(!existingUser.getMotdepasse()
                .equals(utilisateur.getMotdepasse())) {

            throw new RuntimeException(
                    "Mot de passe incorrect"
            );
        }

        return existingUser;
    }

    // Get all users
    public List<Utilisateur> getAllUtilisateurs() {
        return utilisateurRepository.findAll();
    }

    // Get user by id
    public Utilisateur getUtilisateurById(Long id) {

        return utilisateurRepository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException(
                                "Utilisateur introuvable"
                        )
                );
    }

    // Update user
    public Utilisateur updateUtilisateur(
            Long id,
            Utilisateur updatedUser
    ) {

        Utilisateur utilisateur =
                getUtilisateurById(id);

        utilisateur.setNom(updatedUser.getNom());
        utilisateur.setPrenom(updatedUser.getPrenom());
        utilisateur.setTelephone(updatedUser.getTelephone());
        utilisateur.setAdresse(updatedUser.getAdresse());
        utilisateur.setEmail(updatedUser.getEmail());
        utilisateur.setMotdepasse(updatedUser.getMotdepasse());
        utilisateur.setEtatUser(updatedUser.getEtatUser());

        return utilisateurRepository.save(utilisateur);
    }

    // Delete user
    public void deleteUtilisateur(Long id) {

        Utilisateur utilisateur =
                getUtilisateurById(id);

        // Produits utilisateur
        List<Produit> produits =
                produitRepository.findByUtilisateurId(id);

        for (Produit produit : produits) {

            Long produitId = produit.getId();

            // Evaluations produit
            List<Evaluation> evaluationsProduit =
                    evaluationRepository.findByProduitId(
                            produitId
                    );

            evaluationRepository
                    .deleteAll(evaluationsProduit);

            // Demandes liées produit
            List<Demmandechange> demandes =
                    demmandechangeRepository
                            .findByProduitId(produitId);

            for (Demmandechange demande : demandes) {

                Long demandeId = demande.getId();

                // Images échange
                List<ImageEchange> images =
                        imageEchangeRepository
                                .findByDemmandechange_Id(
                                        demandeId
                                );

                imageEchangeRepository
                        .deleteAll(images);

                demmandechangeRepository
                        .delete(demande);
            }

            produitRepository.delete(produit);
        }

        // Evaluations reçues
        evaluationRepository
                .deleteAll(
                        evaluationRepository
                                .findByUtilisateurNoteeId(id)
                );

        // Evaluations données
        evaluationRepository
                .deleteAll(
                        evaluationRepository
                                .findByUtilisateurNoteurId(id)
                );

        // Demandes envoyées
        List<Demmandechange> demandesEnvoyees =
                demmandechangeRepository
                        .findByUtilisateurId(id);

        for (Demmandechange demande : demandesEnvoyees) {

            List<ImageEchange> images =
                    imageEchangeRepository
                            .findByDemmandechange_Id(
                                    demande.getId()
                            );

            imageEchangeRepository
                    .deleteAll(images);

            demmandechangeRepository
                    .delete(demande);
        }

        utilisateurRepository.delete(utilisateur);
    }
}