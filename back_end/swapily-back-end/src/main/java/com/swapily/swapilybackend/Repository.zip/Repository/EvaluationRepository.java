package com.swapily.swapilybackend.Repository;

import com.swapily.swapilybackend.Entity.Evaluation;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface EvaluationRepository
        extends JpaRepository<Evaluation, Long> {

    // Evaluations reçues par utilisateur
    List<Evaluation>
    findByUtilisateurNoteeId(Long utilisateurNoteeId);

    // Vérifier si utilisateur a déjà évalué produit
    Optional<Evaluation>
    findByUtilisateurNoteurIdAndProduitId(
            Long utilisateurNoteurId,
            Long produitId
    );

    // Evaluations d'un produit
    List<Evaluation>
    findByProduitId(Long produitId);

    // Evaluations faites par utilisateur
    List<Evaluation>
    findByUtilisateurNoteurId(Long utilisateurNoteurId);
}