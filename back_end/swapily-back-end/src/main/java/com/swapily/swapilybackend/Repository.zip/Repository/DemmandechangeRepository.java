package com.swapily.swapilybackend.Repository;

import com.swapily.swapilybackend.Entity.Demmandechange;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface DemmandechangeRepository
        extends JpaRepository<Demmandechange, Long> {

    // Demandes d'un utilisateur
    List<Demmandechange>
    findByUtilisateurIdOrderByIdDesc(Long utilisateurId);

    // Demandes d'un utilisateur selon statut
    List<Demmandechange>
    findByUtilisateurIdAndStatutOrderByIdDesc(
            Long utilisateurId,
            String statut
    );

    // Demandes reçues sur produits d'un utilisateur
    List<Demmandechange>
    findByProduitUtilisateurIdAndStatutOrderByIdDesc(
            Long utilisateurId,
            String statut
    );

    // Demandes liées à produit
    List<Demmandechange>
    findByProduitId(Long produitId);

    // Toutes les demandes triées
    List<Demmandechange>
    findAllByOrderByIdDesc();

    // Vérifier si utilisateur a déjà envoyé demande
    List<Demmandechange>
    findByUtilisateurIdAndProduitId(
            Long utilisateurId,
            Long produitId
    );

    // Première demande validée d'un produit
    Optional<Demmandechange>
    findFirstByProduitIdAndStatut(
            Long produitId,
            String statut
    );

    List<Demmandechange> findByUtilisateurId(Long id);
}