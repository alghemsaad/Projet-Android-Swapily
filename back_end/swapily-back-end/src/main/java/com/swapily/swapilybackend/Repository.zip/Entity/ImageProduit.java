package com.swapily.swapilybackend.Entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "image_produit")

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder

public class ImageProduit {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Lob
    @Column(columnDefinition = "LONGBLOB")
    private byte[] imageData;

    @ManyToOne(fetch = FetchType.LAZY)

    @JoinColumn(name = "produit_id")

    @JsonIgnore
    private Produit produit;
}