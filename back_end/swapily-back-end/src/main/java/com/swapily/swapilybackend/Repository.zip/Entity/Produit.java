package com.swapily.swapilybackend.Entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.List;

@Entity
@Table(name = "produit")

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder

public class Produit {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String titre;

    @Column(length = 1000)
    private String description;

    @Column(nullable = false)
    private String categorie;

    private String localisation;

    private String statut;

    @Column(name = "utilisateur_id")
    private Long utilisateurId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(
            name = "utilisateur_id",
            insertable = false,
            updatable = false
    )
    private Utilisateur utilisateur;

    @OneToMany(mappedBy = "produit", cascade = CascadeType.ALL)
    private List<ImageProduit> images;
}