package com.swapily.swapilybackend.Controller;

import lombok.RequiredArgsConstructor;
import com.swapily.swapilybackend.Entity.Utilisateur;
import com.swapily.swapilybackend.Service.UtilisateurService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/utilisateurs")

@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:5173")

public class UtilisateurController {

    private final UtilisateurService utilisateurService;

    // Signup
    @PostMapping("/signup")
    public ResponseEntity<?> signUp(
            @RequestBody Utilisateur utilisateur
    ) {
        return ResponseEntity.ok(
                utilisateurService.signUp(utilisateur)
        );
    }

    // Signin
    @PostMapping("/signin")
    public ResponseEntity<?> signIn(
            @RequestBody Utilisateur utilisateur
    ) {
        return ResponseEntity.ok(
                utilisateurService.signIn(utilisateur)
        );
    }

    // Get all users
    @GetMapping
    public List<Utilisateur> getAllUtilisateurs() {
        return utilisateurService.getAllUtilisateurs();
    }

    // Get user by id
    @GetMapping("/{id}")
    public ResponseEntity<Utilisateur> getUtilisateurById(
            @PathVariable Long id
    ) {
        return ResponseEntity.ok(
                utilisateurService.getUtilisateurById(id)
        );
    }

    // Update user
    @PutMapping("/{id}")
    public ResponseEntity<Utilisateur> updateUtilisateur(
            @PathVariable Long id,
            @RequestBody Utilisateur utilisateur
    ) {
        return ResponseEntity.ok(
                utilisateurService.updateUtilisateur(id, utilisateur)
        );
    }

    // Delete user
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteUtilisateur(
            @PathVariable Long id
    ) {
        utilisateurService.deleteUtilisateur(id);

        return ResponseEntity.ok(
                "Utilisateur supprimé avec succès"
        );
    }
}