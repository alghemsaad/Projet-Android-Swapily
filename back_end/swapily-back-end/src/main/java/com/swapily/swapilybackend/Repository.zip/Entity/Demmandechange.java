package com.swapily.swapilybackend.Entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.List;

@Entity
@Table(name = "demandeechange")

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder

public class Demmandechange {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String dateDE;

    private String statut;

    @Column(length = 1000)
    private String message;

    @Column(name = "utilisateur_id")
    private Long utilisateurId;

    @Column(name = "produit_id")
    private Long produitId;

    @ManyToOne(fetch = FetchType.LAZY)

    @JoinColumn(
            name = "produit_id",
            insertable = false,
            updatable = false
    )

    private Produit produit;

    @ManyToOne(fetch = FetchType.LAZY)

    @JoinColumn(
            name = "utilisateur_id",
            insertable = false,
            updatable = false
    )

    private Utilisateur utilisateur;

    @OneToMany(
            mappedBy = "demmandechange",
            cascade = CascadeType.ALL
    )

    private List<ImageEchange> images;
}