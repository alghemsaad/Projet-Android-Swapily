package com.swapily.swapilybackend.Repository;

import com.swapily.swapilybackend.Entity.Produit;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProduitRepository
        extends JpaRepository<Produit, Long> {

    // Tous les produits triés du plus récent au plus ancien
    List<Produit> findAllByOrderByIdDesc();

    // Produits par statut
    List<Produit> findByStatutOrderByIdDesc(String statut);

    // Produits d'un utilisateur
    List<Produit> findByUtilisateurIdOrderByIdDesc(Long utilisateurId);

    // Recherche par titre
    List<Produit> findByTitreContainingIgnoreCase(String titre);

    // Produits par catégorie
    List<Produit> findByCategorieIgnoreCase(String categorie);

    // Produits par catégorie + statut
    List<Produit> findByCategorieAndStatut(
            String categorie,
            String statut
    );

    // Produits d'un utilisateur selon statut
    List<Produit> findByUtilisateurIdAndStatut(
            Long utilisateurId,
            String statut
    );

    // Recherche par localisation
    List<Produit> findByLocalisationContainingIgnoreCase(
            String localisation
    );

    List<Produit> findByUtilisateurId(Long id);
}