package com.swapily.swapilybackend.Repository;

import com.swapily.swapilybackend.Entity.ImageEchange;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ImageEchangeRepository
        extends JpaRepository<ImageEchange, Long> {

    // Images liées à une demande d'échange
    List<ImageEchange>
    findByDemmandechange_Id(Long demmandechangeId);
}