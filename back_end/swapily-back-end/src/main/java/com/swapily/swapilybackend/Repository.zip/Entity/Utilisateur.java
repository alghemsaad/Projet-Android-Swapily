package com.swapily.swapilybackend.Entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "utilisateur")

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder

public class Utilisateur {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 100)
    private String nom;

    @Column(nullable = false, length = 100)
    private String prenom;

    @Column(nullable = false, unique = true)
    private String email;

    @Column(nullable = false)
    private String motdepasse;

    @Column(length = 20)
    private String telephone;

    private String adresse;

    @Column(name = "etat_user")
    private String etatUser;
}