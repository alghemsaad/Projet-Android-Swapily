package com.swapily.swapilybackend.Entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "image_echange")

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder

public class ImageEchange {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Lob
    @Column(columnDefinition = "LONGBLOB")
    private byte[] imageData;

    @ManyToOne(fetch = FetchType.LAZY)

    @JoinColumn(name = "demmande_echange_id")

    @JsonIgnore
    private Demmandechange demmandechange;
}