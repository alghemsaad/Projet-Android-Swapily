package com.swapily.swapilybackend.Entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "avis")

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder

public class Avis {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(length = 1000)
    private String contenu;

    private int noteApp;

    @Column(name = "utilisateur_id")
    private Long utilisateurId;

    @ManyToOne(fetch = FetchType.LAZY)

    @JoinColumn(
            name = "utilisateur_id",
            insertable = false,
            updatable = false
    )

    private Utilisateur utilisateur;
}