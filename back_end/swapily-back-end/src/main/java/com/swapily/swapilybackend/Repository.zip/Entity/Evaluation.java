package com.swapily.swapilybackend.Entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "evaluation")

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder

public class Evaluation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private int note;

    @Column(length = 1000)
    private String commentaire;

    private String dateEvaluation;

    @Column(name = "utilisateur_noteur_id")
    private Long utilisateurNoteurId;

    @Column(name = "utilisateur_notee_id")
    private Long utilisateurNoteeId;

    @Column(name = "produit_id")
    private Long produitId;

    @ManyToOne(fetch = FetchType.LAZY)

    @JoinColumn(
            name = "utilisateur_noteur_id",
            referencedColumnName = "id",
            insertable = false,
            updatable = false
    )

    private Utilisateur utilisateurNoteur;

    @ManyToOne(fetch = FetchType.LAZY)

    @JoinColumn(
            name = "utilisateur_notee_id",
            referencedColumnName = "id",
            insertable = false,
            updatable = false
    )

    private Utilisateur utilisateurNotee;

    @ManyToOne(fetch = FetchType.LAZY)

    @JoinColumn(
            name = "produit_id",
            referencedColumnName = "id",
            insertable = false,
            updatable = false
    )

    private Produit produit;
}